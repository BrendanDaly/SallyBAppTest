﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace ChangeTemperature
{
    public class ThermContract : TemperatureService.ITemperatureCallback
    {
        
        public void TemperatureChange(TemperatureService.ThermometerSubscription TemperaturePublication)
        {
           
        }
        public void ReachedFreezingPoint(bool bolFP)
        { }

        public void ReachedBoilingPoint(bool bolBP)
        { }
    }
}
