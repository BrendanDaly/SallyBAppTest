﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace ChangeTemperature
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string strPublishTempDegrees = "";
        TemperatureService.TemperatureClient TempClientPub = new TemperatureService.TemperatureClient(new InstanceContext(new ThermContract()));
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            // get what degress the temperature is being reported in
            if (strPublishTempDegrees == "")
            {
                MessageBox.Show("You need to select a Temperature Degree before Submitting.","Info",MessageBoxButton.OK,MessageBoxImage.Information);
                return;
            }
            double decResult;
            if (double.TryParse(txtNewTemp.Text, out decResult))
            {


                switch (strPublishTempDegrees.First().ToString())
                {
                    case "C":
                    case "F":
                        double decTemp = new double();
                        decTemp = double.Parse(txtNewTemp.Text);
                        TempClientPub.PublishTemperatureChange(decTemp, strPublishTempDegrees);
                        break;
                    default:
                        MessageBox.Show("Error in Temperature Degrees. Temp not submitted.", "ERROR", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                }
            }
            else
            {
                MessageBox.Show("Please neter a valid temperature.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);

            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            switch (TempClientPub.State)
            {

                case CommunicationState.Opened:
                case CommunicationState.Opening:
                case CommunicationState.Created:
                    TempClientPub.Close();
                    break;
                case CommunicationState.Closed:
                case CommunicationState.Closing:
                case CommunicationState.Faulted:

                    break;
            }
        }

        private void rdoDegrees_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            switch (rb.Name.ToUpper())
            {
                case "RDOF":
                    strPublishTempDegrees = "F";
                    break;
                case "RDOC":
                    strPublishTempDegrees = "C";
                    break;
            }
        }

        private void SelectNewTemp(object sender, RoutedEventArgs e)
        {
            TextBox tb = (sender as TextBox);
            if (tb != null)
            {
                tb.SelectAll();
            }
        }

        private void txtNewTemp_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TextBox tb = (sender as TextBox);
            if (tb != null)
            {
                if (!tb.IsKeyboardFocusWithin)
                {
                    e.Handled = true;
                    tb.Focus();
                }
            }
        }
    }
}
