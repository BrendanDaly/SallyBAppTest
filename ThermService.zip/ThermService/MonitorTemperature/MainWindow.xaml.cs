﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Collections.ObjectModel;

namespace MonitorTemperature
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        TemperatureService.TemperatureClient TempClient = null;
        ThermContract _tempContract = new ThermContract();
        TemperatureService.ThermometerSubscription MySubscription = new TemperatureService.ThermometerSubscription();
        string strSubscriptionTempDegrees = "";
        ObservableCollection<TemperatureService.ThermometerSubscription> NewTemperatures;

        public MainWindow()
        {
            NewTemperatures = new ObservableCollection<TemperatureService.ThermometerSubscription>();
            InitializeComponent();
            //textBox.Text = _tempContract.Temp.ToString();
            dataGrid.ItemsSource = NewTemperatures;
            _tempContract.PropertyChanged += _tempContract_PropertyChanged;
        }

        private void _tempContract_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            //throw new NotImplementedException();
            //MessageBox.Show(e.PropertyName);
            switch(e.PropertyName)
            {
                case "CurrentIssue":
                    //dataGrid.DataContext = sender;
                    NewTemperatures.Add(((ThermContract)sender).CurrentIssue);
                    break;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //validate subscription. - could also refactor to move validation to service.
            // get what degress the temperature is being reported in
            if (strSubscriptionTempDegrees == "")
            {
                MessageBox.Show("You need to select a Temperature Degree before Submitting.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            MySubscription.TemperatureDegrees = strSubscriptionTempDegrees;
            
            //Validate correct notify - possible refactor use enums from service.

            if (!ValidateTempNotify(txtTempNotify.Text)) { MessageBox.Show("Acceptable Values are ALL , UP or DOWN.", "Temperature Notify", MessageBoxButton.OK, MessageBoxImage.Exclamation);return; }
            MySubscription.TemperatureNotify = txtTempNotify.Text.Trim().ToUpper();

            if (!ValidatePointNotify(txtFreezingPointNotify.Text)) { MessageBox.Show("Acceptable Values are ALL or ONCE.", "Freezing Point Notify", MessageBoxButton.OK, MessageBoxImage.Exclamation); return; }
            MySubscription.FreezingPointNotify = txtFreezingPointNotify.Text.Trim().ToUpper();

            if (!ValidatePointNotify(txtBoilingPointNotify.Text)) { MessageBox.Show("Acceptable Values are ALL or ONCE.", "Boiling Point Notify", MessageBoxButton.OK, MessageBoxImage.Exclamation); return; }
            MySubscription.BoilingPointNotify = txtBoilingPointNotify.Text.Trim().ToUpper();
            //Validate Variance Change
            double decResult;
            if (double.TryParse(txtInsignificantVariance.Text, out decResult))
            {
                MySubscription.InsignificantVariance = double.Parse(txtInsignificantVariance.Text);
            }
            else
            {
                MessageBox.Show("Please Enter a valid number for Insignifact Variance.", "Insignifact Variance", MessageBoxButton.OK, MessageBoxImage.Exclamation); return;
            }
            // Validate FreezingPoint Override
            // Check if field is blank if not then validate number..
            if (txtFreezingPoint.Text.Trim() != "")
            {
                if (double.TryParse(txtFreezingPoint.Text, out decResult))
                {
                    TemperatureService.ChangeTemperaturePoint NewFP = new TemperatureService.ChangeTemperaturePoint();
                    NewFP.NewTemperaturePoint = double.Parse(txtFreezingPoint.Text);
                    MySubscription.ChangeFreezingPoint = NewFP;
                }
                else
                {
                    MessageBox.Show("You have entered a value for a new Freezing Point that is not a number. Enter a valid number or leave blank.", "Freezing Point", MessageBoxButton.OK, MessageBoxImage.Exclamation); return;
                }
            }
            else
            {
                // make sure that the FP is null if the blank. This accounts for the situation here the user put in a value and then removed it prior to subscription.
                MySubscription.ChangeFreezingPoint = null;
            }
            // Validate Boiling Point Override
            // Check if field is blank if not then validate number..
            if (txtBoilingPoint.Text.Trim() != "")
            {
                if (double.TryParse(txtBoilingPoint.Text, out decResult))
                {
                    TemperatureService.ChangeTemperaturePoint NewBP = new TemperatureService.ChangeTemperaturePoint();
                    NewBP.NewTemperaturePoint = double.Parse(txtBoilingPoint.Text);
                    MySubscription.ChangeBoilingPoint = NewBP;
                }
                else
                {
                    MessageBox.Show("You have entered a value for a new Boiling Point that is not a number. Enter a valid number or leave blank.", "Boiling Point", MessageBoxButton.OK, MessageBoxImage.Exclamation); return;
                }
            }
            else
            {
                // make sure that the BP is null if the blank. This accounts for the situation here the user put in a value and then removed it prior to subscription.
                MySubscription.ChangeBoilingPoint = null;
            }

            
            TempClient = new TemperatureService.TemperatureClient(new InstanceContext(_tempContract));
            MySubscription.SubscriberName = DateTime.Now.Ticks.ToString();
            _tempContract.SubscriberName = MySubscription.SubscriberName;
            TempClient.Subscribe(MySubscription);
            this.Title = this.Title + " - " + MySubscription.SubscriberName;
            //dataGrid.DataContext = _tempContract;
            btnSubscribe.IsEnabled = false; 
            
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            switch(TempClient?.State)
            {

                case CommunicationState.Opened:
                case CommunicationState.Opening:
                case CommunicationState.Created:
                    TempClient.Unsubscribe();
                    TempClient.Close();
                    break;
                case CommunicationState.Closed:
                case CommunicationState.Closing:
                case CommunicationState.Faulted:

                    break;
            }
          
        }

        private bool ValidateTempNotify(string strNotifyValue)
        {
            bool bolReturn = false;
            if (strNotifyValue == null) { return bolReturn; }
            // Think about using enums to validate this. can be done during a refactor
            // ALL - notify me of all temperature changes
            // UP - only notify me if the temperature is rising
            // DOWN - only notify me if the temperature is going down

            switch (strNotifyValue.Trim().ToUpper())
            {
                case "ALL":
                case "UP":
                case "DOWN":
                    bolReturn = true;
                    break;
            }
            return bolReturn;
        }

        private bool ValidatePointNotify(string strNotifyValue)
        {
            bool bolReturn = false;
            // Think about using enums to validate this. can be done during a refactor
            // ALL - notify me of all temperature changes
            // ONCE - only notify me once if the temp point is reached or gone past. Do not continually notify me


            switch (strNotifyValue.Trim().ToUpper())
            {
                case "ALL":
                case "ONCE":
                    bolReturn = true;
                    break;
            }
            return bolReturn;
        }

        private void rdoDegrees_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            switch (rb.Name.ToUpper())
            {
                case "RDOF":
                    strSubscriptionTempDegrees = "F";
                    break;
                case "RDOC":
                    strSubscriptionTempDegrees = "C";
                    break;
            }
        }
    }
}
