﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ComponentModel;

namespace MonitorTemperature
{
   
    public class ThermContract : TemperatureService.ITemperatureCallback, INotifyPropertyChanged
    {
        /// <summary>
        /// This class is used as the callback from the service provider to report temperature changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        // Create the OnPropertyChanged method to raise the event
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        //MVVM notify front end of temperature changed
        private double _Temp;
        public double Temp { get { return _Temp; } set { _Temp = value; OnPropertyChanged("Temp"); } }

        private TemperatureService.ThermometerSubscription _CurrentIssue;
        public TemperatureService.ThermometerSubscription CurrentIssue { get { return _CurrentIssue; } set { _CurrentIssue = value; OnPropertyChanged("CurrentIssue"); } }

        private bool _FreezingPointReached = false;
        public bool FreezingPointReached { get { return _FreezingPointReached; } set { _FreezingPointReached = value; OnPropertyChanged("FreezingPoint"); } }

        private bool _BoilingPointReached=false;
        public bool BoilingPointReached { get { return _BoilingPointReached; } set { _BoilingPointReached = value; OnPropertyChanged("BoilingPoint"); } }


        public string SubscriberName { get;  set; }


        public void TemperatureChange(TemperatureService.ThermometerSubscription TemperaturePublication)
        //public void TemperatureChange(double decTemp)
        {
            CurrentIssue = TemperaturePublication;
            Temp = TemperaturePublication.Temperature;
           // MessageBox.Show(Temp.ToString());

        }

        public void ReachedFreezingPoint(bool bolFP)
        {
            FreezingPointReached = true;
            MessageBox.Show(SubscriberName + " - "+"Callback - FreezingPointReached");
          
        }
        public void ReachedBoilingPoint(bool bolFP)
        {
            BoilingPointReached = true;
            MessageBox.Show(SubscriberName + " - " + "CallBack - BoilingPointReached");
           
        }
    }
}
