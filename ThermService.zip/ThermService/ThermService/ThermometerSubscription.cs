﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.Runtime.Serialization;
namespace ThermService
{
    [DataContract]
    public class ThermometerSubscription 
    {
        // Class will be used to send and receive data from client during the subscription / publish process
        // set the hi/lo points to null. this will indicate that the standard temperatures for this point will be used.
        // if the subscriber wants to change these points then the class will not be null.
        // we default to all notification 
        // default to send all tempchange 0 variance
        [DataMember] public DateTime TemperatureDate { get;  set; }
        [DataMember] public string SubscriberName { get; set; }
        [DataMember] public double Temperature { get;  set; }
        [DataMember] public double PrevTemperature { get;  set; }
        [DataMember] public string SubscriptionType { get;  set; } = "NEW";
        [DataMember] public string TemperatureDegrees { get; set; }
        [DataMember] public string TemperatureNotify { get; set; } = "ALL";
        [DataMember] public string TemperatureDirection { get;  set; }
        [DataMember] public ChangeTemperaturePoint ChangeFreezingPoint { get; set; } = null;
        [DataMember] public string FreezingPointNotify { get; set; } = "ALL";
        [DataMember] public bool FreezingPointReached { get;  set; }
        [DataMember] public ChangeTemperaturePoint ChangeBoilingPoint { get; set; } = null;
        [DataMember] public string BoilingPointNotify { get; set; } = "ALL";
        [DataMember] public bool BoilingPointReached { get;  set; }
        [DataMember] public double InsignificantVariance { get; set; } = 0;
        [DataMember] public string SessionID { get; set; }

    }
}