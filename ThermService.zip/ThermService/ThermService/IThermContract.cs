﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace ThermService
{
    interface IThermContract
    {

        [OperationContract(IsOneWay = true)]
        //void TemperatureChange(double decTemp);
        void TemperatureChange(ThermometerSubscription TemperaturePublication);

        [OperationContract(IsOneWay = true)]
        void ReachedFreezingPoint(bool bolFP);

        [OperationContract(IsOneWay = true)]
        void ReachedBoilingPoint(bool bolBP);

    }
}
