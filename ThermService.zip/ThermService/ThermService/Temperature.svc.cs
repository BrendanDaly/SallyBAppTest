﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ThermService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Temperature" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Temperature.svc or Temperature.svc.cs at the Solution Explorer and start debugging.
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
    public class Temperature : ITemperature
    {
        IThermContract ThermCallBack = null;
        private static List<IThermContract> Subscribers = new List<IThermContract>();
        private static List<ThermometerSubscription> Subscriptions = new List<ThermometerSubscription>();
        private double FPFarenheit = 32.000;
        private double FPCelsius = 0.000;
        private double BPFarenheit = 212.000;
        private double BPCelsius = 100.000;
       // private static List<IThermContract> Subscribers = new List<IThermContract>();
        public void Subscribe(ThermometerSubscription ClientSubscription)
        {
            ThermCallBack = OperationContext.Current.GetCallbackChannel<IThermContract>();
            Subscribers.Add(ThermCallBack);
            ClientSubscription.SessionID = ((IClientChannel)ThermCallBack).SessionId;
            ClientSubscription.SubscriptionType = "NEW"; 
            Subscriptions.Add(ClientSubscription);

        }

        public void Unsubscribe()
        {
            ThermCallBack = OperationContext.Current.GetCallbackChannel<IThermContract>();
            lock (Subscribers)
            {
                var currentSubscriptionRemove =
                                from clientSub in Subscriptions
                                where clientSub.SessionID == ((IClientChannel)ThermCallBack).SessionId
                                select clientSub;
                ThermometerSubscription ClientSubscriptionRemove = currentSubscriptionRemove.First();
                Subscriptions.Remove(ClientSubscriptionRemove);
                Subscribers.Remove(ThermCallBack);
            }
        }
        public void PublishTemperatureChange(double decTemp,string strTempDegrees)
        {
            foreach (IThermContract ITC in Subscribers)
            {
               
                try {
                    // Only publish to active subscribers that are connected. other wise remove them
                    switch (((ICommunicationObject)ITC).State)
                    {
                        case CommunicationState.Opened:
                            // Get the clients subscription for this subscriber
                            var currentSubscription =
                                                       from clientSub in Subscriptions
                                                       where clientSub.SessionID == ((IClientChannel)ITC).SessionId
                                                       select clientSub;
                            ThermometerSubscription ClientSubscription = currentSubscription.First();
                            
                            // Get the current temperature based on the client subscription. Convert if necessary.
                            double decCurrentTemp = convert(strTempDegrees, ClientSubscription.TemperatureDegrees.Trim(), decTemp);
                            
                            // Get the previous temperature and see if it is within the client's variance
                            double decPreviousTemp = ClientSubscription.Temperature;
                            ClientSubscription.PrevTemperature = decPreviousTemp;
                            bool bolTempOutsideVariance = TempOutsideVariance(decPreviousTemp, decCurrentTemp, ClientSubscription.InsignificantVariance);

                           

                            // get the appropriate FP / BP
                            double decFP = 0;
                            double decBP = 0;
                            switch (ClientSubscription.TemperatureDegrees.Trim())
                            {
                                case "C":
                                    decFP = FPCelsius;
                                    decBP = BPCelsius;
                                    break;
                                case "F":
                                    decFP = FPFarenheit;
                                    decBP = BPFarenheit;
                                    break;

                            }

                            //Check if we are overriding the standard FP
                            if (ClientSubscription.ChangeFreezingPoint != null)
                            {
                                //override FP
                                decFP = ClientSubscription.ChangeFreezingPoint.NewTemperaturePoint;
                            }
                            //Check if we are overriding the standard BP
                            if (ClientSubscription.ChangeBoilingPoint != null)
                            {
                                //override FP
                                decBP = ClientSubscription.ChangeBoilingPoint.NewTemperaturePoint;
                            }

                            //check if freezing point reached
                            ClientSubscription.FreezingPointReached = FPReached(decFP, decCurrentTemp);

                            //check if boiling point reached
                            ClientSubscription.BoilingPointReached = BPReached(decBP, decCurrentTemp);
                            

                            //check the freezing point notification subscrption and notify
                            if (ClientSubscription.FreezingPointReached)
                            {
                                switch (ClientSubscription.FreezingPointNotify.ToUpper())
                                {
                                    case "ALL":
                                        ITC.ReachedFreezingPoint(ClientSubscription.FreezingPointReached);
                                        break;
                                    case "ONCE":
                                        // Change FP Notify from Once to REACHED
                                        ClientSubscription.FreezingPointNotify = "REACHED";
                                        ITC.ReachedFreezingPoint(ClientSubscription.FreezingPointReached);
                                        break;
                                }
                            }
                            //check the boiling point notification subscrption and notify
                            if (ClientSubscription.BoilingPointReached)
                            {
                                switch (ClientSubscription.BoilingPointNotify.ToUpper())
                                {
                                    case "ALL":
                                        ITC.ReachedBoilingPoint(ClientSubscription.BoilingPointReached);
                                        break;
                                    case "ONCE":
                                        // Change BP Notify from Once to REACHED
                                        ClientSubscription.BoilingPointNotify = "REACHED";
                                        ITC.ReachedBoilingPoint(ClientSubscription.BoilingPointReached);
                                        break;
                                }
                            }

                            // Get the direction of the temperature
                            string strTempDirection = "";
                            if (ClientSubscription.SubscriptionType != "NEW")
                            {
                                strTempDirection = TempDirection(decPreviousTemp, decCurrentTemp);
                                ClientSubscription.TemperatureDirection = strTempDirection;
                            }
                            else
                            {
                                ClientSubscription.SubscriptionType = "SUBSCRIBED";
                                ClientSubscription.TemperatureDirection = "NEW";
                                strTempDirection = "NEW";
                            }
                            //check the temperature notification subscription and send info
                            ClientSubscription.TemperatureDate = DateTime.Now;
                            if (bolTempOutsideVariance)
                            {
                                //update the temperature to the subscription
                                ClientSubscription.Temperature = decCurrentTemp;
                                switch (ClientSubscription.TemperatureNotify.ToUpper())
                                {
                                    case "ALL":
                              
                                        ITC.TemperatureChange(ClientSubscription);
                                        break;
                                    case "DOWN":
                                        if (strTempDirection == "DOWN") { ITC.TemperatureChange(ClientSubscription); }
                                        if (strTempDirection == "NEW") { ITC.TemperatureChange(ClientSubscription); } // Need to send the first subscription out
                                        break;
                                    case "UP":
                                        if (strTempDirection == "UP") { ITC.TemperatureChange(ClientSubscription); }
                                        if (strTempDirection == "NEW") { ITC.TemperatureChange(ClientSubscription); }// Need to send the first subscription out
                                        break;
                                }
                            }
                            break;
                        case CommunicationState.Closed:
                        case CommunicationState.Closing:
                        case CommunicationState.Faulted:
                            lock (Subscribers)
                            {
                                var currentSubscriptionRemove =
                                                                from clientSub in Subscriptions
                                                                where clientSub.SessionID == ((IClientChannel)ITC).SessionId
                                                                select clientSub;
                                ThermometerSubscription ClientSubscriptionRemove = currentSubscriptionRemove.First();
                                Subscriptions.Remove(ClientSubscriptionRemove);
                                Subscribers.Remove(ITC);
                            }
                            break;
                    }

                }
                catch (Exception ex)
                {
                    //implement fault code here to client
                }
            }
        }

        private double convert(string strConvertFrom,string strConvertTo,double decTemp)
        {
            double decReturn = 9999999999.9999999;
            switch (strConvertFrom.ToUpper() + "-" + strConvertTo.ToUpper())
            {
                //°C x  9 / 5 + 32 = °F
                //(°F - 32)  x  5 / 9 = °C

                case "C-F":
                    decReturn = decTemp * (9.000/5.000) + 32;
                    break;
                case "F-C":
                    decReturn = (decTemp - 32) * (5.000/9.000);
                    break;
                case "C-C":
                case "F-F":
                    decReturn = decTemp;
                    break;
            }
            return decReturn;
        }
        private bool FPReached(double decFP,double decTemp)
        {
            bool bolReturn = false;
            if(decTemp<=decFP) { bolReturn = true; }
            return bolReturn;
        }

        private bool BPReached(double decBP, double decTemp)
        {
            bool bolReturn = false;
            if (decTemp >= decBP) { bolReturn = true; }
            return bolReturn;
        }

        private bool TempOutsideVariance(double decPrevTemp,double decTemp, double decVariance)
        {
            bool bolReturn = false;
            double decChangeInTemp = Math.Abs(decPrevTemp - decTemp);
            if (decChangeInTemp >=decVariance)
                { bolReturn = true; }
            return bolReturn;
        }

        private string TempDirection(double decPrevTemp, double decTemp)
        {
            string strReturn = "";
            double decChangeInTemp = decPrevTemp - decTemp;
            if (decPrevTemp < decTemp)
            { strReturn = "UP"; }
            else
            {
                strReturn = "DOWN";
            }

            //if 0 change then no change in direction
            if (decChangeInTemp == 0) { strReturn = "SAME"; }
            
            return strReturn;
        }


    }
}
