﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ThermService
{
    public class ChangeTemperaturePoint
    {
        public double NewTemperaturePoint { get; set; }
    }
}